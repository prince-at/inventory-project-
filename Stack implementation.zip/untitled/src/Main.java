// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.Stack;
public class Main {
    public static void main(String[] args) {
        Stack mystack = new Stack();
        //Stack<Integer> stack_obj = new Stack<>();
        //Stack<String> str_stack = new Stack<>();
        Stack<Integer> myStack = new Stack<>();
        Stack<String>myOwnStack = new Stack<>();

        myStack.push(100);
        myStack.push(200);
        myStack.push(1000);
        myOwnStack.push("hello");

        Stack<Integer> intStack = new Stack<>();
        int val = intStack.pop();
        int vals = intStack.pop();

    }
    }
