package com.example.demo.Data;
import com.example.demo.repository.Item;


import java.util.*;

public class InventoryManagementSystem {
    //String ims;
    private static final String url = "jdbc:mssql://localhost:1433/SQLQuery16.sql?useSSL=false";
    private static String username = "admin";
    private static String password = "";
    private static HashMap<String, String> vendors = new HashMap<>();
    private static HashMap<String, Integer> productSales = new HashMap<>();
    //stack for category 1 to 4
    private static Stack<Item> beveragesStack = new Stack<>();
    private static Stack<Item> breadStack = new Stack<>();
    private static Stack<Item> cannedGoodsStack = new Stack<>();
    private static Stack<Item> dairyStack = new Stack<>();
    // Queue for category 5 to 7
    private static Queue<Item> dryBakedGoodsQueue = new LinkedList<>();
    private static Queue<Item> frozenQueue = new LinkedList<>();
    private static Queue<Item> meatQueue = new LinkedList<>();
    //list for category 8 to 11
    private static List<Item> farmProduceList = new ArrayList<>();
    private static List<Item> homeCleanersList = new ArrayList<>();
    private static List<Item> paperGoodsList = new ArrayList<>();
    private static List<Item> homeCareList = new ArrayList<>();

    // method to add new item to the inventory
    public static void addItem(String Item, item){
        //String category = item.getCategory();
        switch(item.category.toLowerCase()){
            case "beverages":
                beveragesStack.push(item);
                break;
            case "bread/bakery":
                breadStack.push(item);
                break;
            case "canned/jarred goods":
                cannedGoodsStack.push(item);
                break;
            case "dairy product":
                dairyStack.push(item);
                break;
            case "dry baked goods":
                dryBakedGoodsQueue.offer(item);
            case "frozen products":
                frozenQueue.offer(item);
                break;
            case "meat":
                meatQueue.add(item);
                break;
            case "farm produce":
                farmProduceList.add(item);
                break;
            case "home cleaners":
                homeCleanersList.add(item);
                break;
            case "paper goods":
                paperGoodsList.add(item);
                break;
            case "home care":
                homeCareList.add(item);
                break;
            default:
                System.out.println("invalid category");
        }
    }
    //method to view vendors
    public static void viewVendors(){
        for (String vendor : vendors.keySet()){
            System.out.println("Vendor name: "+ vendor +", vendor info: "+ vendors.get(vendor));

        }
    }
    //method to view all items in a specific category
    public static void viewItemsInCategory(String category){
        switch (category.toLowerCase()){
            case "beverages":
                for(Item item: beveragesStack){
                    System.out.println("Item name "+ item.getName() +"category: "+ item.getCategory());
                }break;
    //add other cases for other categories
            default:
                System.out.println("invalid category");
                break;
        }
    }
    //method to view bills (sales)
    public static void viewBills(){
        for(String productCode: productSales.keySet()){
            System.out.println("product code: "+ productCode+", Quantity sold: "+ productSales.get(productCode));

        }
    }
    //method to issue goods
    public static void issueGood(){

    }
    //main method
    public static void main(String[] args){
        vendors.put("vendor 1 ", "vendor info 1");
        vendors.put("vendor 2 ", "vendor info 2");

        Item item1 = new Item("coffee", "beverages");
        Item item2 = new Item("sandwich loave", "Bread/bakery");
        Item item3 = new Item("vegetables", "Canned/jarred Goods");
        Item item4 = new Item("Milk", "dairy product");

        addItem(item1);
        addItem(item2);
        addItem(item3);
        addItem(item4);

        viewVendors();
        viewItemsInCategory("beverages");
        viewBills();

    }

    //String ims;
}
