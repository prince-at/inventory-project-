package com.example.demo.Data;

public class inventory {
}
